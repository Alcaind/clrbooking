'use strict';

angular.module('Authentication')

.controller('AuthenticationController',
    ['$scope', '$rootScope', '$location', 'AuthenticationService',
    function ($scope, $rootScope, $location, AuthenticationService) {
        // reset login status
    }]);