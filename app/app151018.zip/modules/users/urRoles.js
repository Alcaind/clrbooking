angular.module('Users')
    .controller('URolesController', ['$scope', 'AuthenticationService', 'makeController', 'ClrStatusSrv', function ($scope, AuthenticationService, makeController, ClrStatusSrv) {

        $scope.ctrl = makeController.n2nController('/users', 'roles', {comment: '', exp_dt: '', status: '0'});
        $scope.ctrl.init();

        $scope.statusOptions = ClrStatusSrv.getStatus('userRoleStatus');
    }])

    .directive('urTable', function () {
        return {
            restrict: 'EA',
            templateUrl: 'modules/users/uviews/urTable.html'
        }
    })
    .directive('evrTable', function () {
        return {
            restrict: 'EA',
            templateUrl: 'modules/users/uviews/evrTable.html'
        }
    })
    .directive('evRolesForm', function () {
        return {
            restrict: 'EA',
            templateUrl: 'modules/users/uviews/evRolesForm.html'
        }
    })
;