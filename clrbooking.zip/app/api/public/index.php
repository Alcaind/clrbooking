<?php
/**
 * Created by PhpStorm.
 * User: alcaind
 * Date: 25/08/2017
 * Time: 3:56 μμ
 */
echo "running";
require __DIR__ . '/../bootstrap/app.php';
echo "running";
$app->run();