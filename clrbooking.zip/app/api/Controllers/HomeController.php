<?php
/**
 * Created by PhpStorm.
 * User: alcaind
 * Date: 25/08/2017
 * Time: 5:27 μμ
 */

namespace App\Controllers;

Class HomeController
{
    public function index($request, $response)
    {
        return 'Home Controller';
    }
}