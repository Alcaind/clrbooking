'use strict';

angular.module('DB')

    .controller('DBController',
        ['$scope', '$rootScope', '$location', 'DBService',
            function ($scope, $rootScope, $location, AuthenticationService) {
                // reset login status
            }]);